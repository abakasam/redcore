﻿'use strict'

export interface ITestWarrior {
    name: string
    redcode: string
    loadfile: string
}
