import { IOptions } from '@simulator/interface/IOptions'

export interface IRules {
    rounds: number
    options: IOptions
}
