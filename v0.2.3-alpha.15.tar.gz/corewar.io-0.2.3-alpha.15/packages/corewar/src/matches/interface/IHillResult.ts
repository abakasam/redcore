import { IHillWarriorResult } from '@matches/interface/IHillWarriorResult'

export interface IHillResult {
    warriors: IHillWarriorResult[]
}
