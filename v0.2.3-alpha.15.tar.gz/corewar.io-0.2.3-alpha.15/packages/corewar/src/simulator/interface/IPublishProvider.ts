export interface IPublishProvider {
    /* eslint-disable-next-line */
    publishSync(type: string, payload: any);
}
