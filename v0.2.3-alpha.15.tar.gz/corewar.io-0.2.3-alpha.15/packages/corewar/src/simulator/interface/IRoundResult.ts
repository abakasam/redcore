export interface IRoundResult {
    winnerId?: number
    /* eslint-disable-next-line */
    winnerData?: any;
    outcome: string
}
