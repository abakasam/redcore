export interface INextExecutionContext {
    warriorId: number
    address: number
}
