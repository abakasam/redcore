﻿export interface IRandom {
    get(max: number): number
}
