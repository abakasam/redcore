﻿import { IToken } from '@parser/interface/IToken'

export interface IParseOperand {
    mode?: IToken
    address?: IToken
}
