﻿export interface IMetaData {
    name: string
    author: string
    strategy: string
}
