const initialState = {
  feedbackMessage: ''
}

export default initialState
