const initialState = {
  signupMessage: ''
}

export default initialState
