import INTERFACE_MODE from './interfaceMode'

const initialState = {
  interfaceMode: INTERFACE_MODE.EDITOR
}

export default initialState
