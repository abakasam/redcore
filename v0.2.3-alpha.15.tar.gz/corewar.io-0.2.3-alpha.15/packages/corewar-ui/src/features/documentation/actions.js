import { action } from '../../actions/creator'

export const MOVE_IMP = 'tutorial/MOVE_IMP'

export const moveImp = () => action(MOVE_IMP)
