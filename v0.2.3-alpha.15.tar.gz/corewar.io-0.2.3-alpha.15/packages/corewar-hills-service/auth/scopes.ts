const Scopes = {
    getHill: 'get-hill-scope',
    createHill: 'create-hill-scope',
    updateHill: 'update-hill-scope',
    deleteHill: 'delete-hill-scope'
}

export default Scopes
