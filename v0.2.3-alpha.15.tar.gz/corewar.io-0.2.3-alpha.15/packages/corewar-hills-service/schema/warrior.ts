export interface IWarrior {
    id: string
    redcode: string
}
