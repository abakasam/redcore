export default interface IId {
    id: string
}
