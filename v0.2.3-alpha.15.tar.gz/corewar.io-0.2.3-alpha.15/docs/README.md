# Corewar Docs

This repository contains the [Read the Docs](http://corewar-docs.readthedocs.io) documentation for Corewar.io

![Documentation Status](http://readthedocs.org/projects/corewar-docs/badge/?version=latest)
