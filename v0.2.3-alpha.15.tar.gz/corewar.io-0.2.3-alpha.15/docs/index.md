![corewar.io](./images/logo-small.png)
#Corewar.io

Welcome to the docs for [corewar.io](https://corewar.io).

The docs are grouped into three areas:

* [Guide to Corewar](corewar/)
* [Redcode Reference](redcode/)
* [Developer Reference](developer/)

Note, these docs are currently in the very early stages of development and are by no means complete.