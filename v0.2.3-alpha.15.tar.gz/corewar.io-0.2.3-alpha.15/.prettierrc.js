module.exports =  {
    semi:  false,
    trailingComma:  'none',
    singleQuote:  true,
    printWidth:  120,
    tabWidth:  4,
  };
  